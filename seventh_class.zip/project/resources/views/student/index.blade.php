@extends("app")

@section("content")
<div class="container-fluid  dashboard-content">
    <!-- ============================================================== -->
    <!-- pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title" style="display: inline;">Students</h2>
                <a href="{{route('student.create')}}"><button class="btn btn-primary" style="float: right;">Add New</button></a>
                <select id="perPage" class="btn btn-info" style="float: right; margin-right:5px;" onchange="perPageChange()">
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="30">30</option>
                    <option value="40">40</option>
                    <option value="50">50</option>
                </select>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Student List</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Name</th>
                                    <th>Roll</th>
                                    <th>Email</th>
                                    <th>Derpartment</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $sl=(($page-1)*$perPage)+1; @endphp
                                @foreach($students as $student)
                                <tr>
                                    <td>{{$sl++}}</td>
                                    <td>{{$student->name}}</td>
                                    <td>{{$student->roll}}</td>
                                    <td>{{$student->email}}</td>
                                    <td>{{$student->department_name}}</td>
                                    <td><a href="{{route('student.edit', $student->id)}}"><button class="btn btn-info">Edit</button></a> | <form style="display: inline;" method="post" action="{{route('student.delete', $student->id)}}">@csrf <button class="btn btn-danger">Delete</button></form></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div style="margin-top: 10px;">
                            {{$students->links()}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end data table multiselects  -->
        <!-- ============================================================== -->
    </div>
</div>

<script type="text/javascript">
    function perPageChange(){
        var perPage = document.getElementById("perPage").value;
        location.replace('{{route("student")}}'+'?perPage='+perPage);
    }
</script>
@endsection