<?php $__env->startSection("content"); ?>
<div class="container-fluid  dashboard-content">
    <!-- ============================================================== -->
    <!-- pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title" style="display: inline;">Students</h2>
                <a href="<?php echo e(route('student.create')); ?>"><button class="btn btn-primary" style="float: right;">Add New</button></a>
                <select id="perPage" class="btn btn-info" style="float: right; margin-right:5px;" onchange="perPageChange()">
                    <option value="10">10</option>
                    <option value="20" <?php if($perPage==20): ?> <?php echo e("selected=1"); ?> <?php endif; ?> >20</option>
                    <option value="30" <?php if($perPage==30): ?><?php echo e("selected=1"); ?><?php endif; ?>>30</option>
                    <option value="40" <?php if($perPage==40): ?><?php echo e("selected=1"); ?><?php endif; ?>>40</option>
                    <option value="50" <?php if($perPage==50): ?><?php echo e("selected=1"); ?><?php endif; ?>>50</option>
                </select>
                <span style="float: right; margin-right:15px;">
                    <input type="text" id="search" class="form-control" style="display: inline; width: 150px;" placeholder="Search" value="<?php echo e($search); ?>">
                    <button class="btn btn-outline-light" id="searchBtn">Search</button>
                </span>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Student List</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered first">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Name</th>
                                    <th>Roll</th>
                                    <th>Email</th>
                                    <th>Derpartment</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sl=(($page-1)*$perPage)+1; ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl++); ?></td>
                                    <td><?php echo e($student->name); ?></td>
                                    <td><?php echo e($student->roll); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <td><?php echo e($student->department_name); ?></td>
                                    <td><a href="<?php echo e(route('student.edit', $student->id)); ?>"><button class="btn btn-info">Edit</button></a> | <form style="display: inline;" method="post" action="<?php echo e(route('student.delete', $student->id)); ?>"><?php echo csrf_field(); ?> <button class="btn btn-danger">Delete</button></form></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div style="margin-top: 10px;" id="pagination">
                            <?php echo e($students->links('paginate')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end data table multiselects  -->
        <!-- ============================================================== -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("javascript"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#pagination").on("click", "a", function(event){
            event.preventDefault();

            var url = $(this).attr("href");
            var perPage = $("#perPage").val();
            
            location.replace(url+"&perPage="+perPage);
        });

        $("#searchBtn").click(function(){
            var search = $("#search").val();
            location.replace('<?php echo e(route("student")); ?>'+'?search='+search);
        });

    });

    function perPageChange(){
        var perPage = document.getElementById("perPage").value;
        location.replace('<?php echo e(route("student")); ?>'+'?perPage='+perPage);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>