<?php $__env->startSection("content"); ?>
<div class="container-fluid  dashboard-content">
    <!-- ============================================================== -->
    <!-- pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- ============================================================== -->
        <!-- validation form -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Student Edit</h5>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('student.update', $student->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Name</label>
                                <input type="text" class="form-control" placeholder="Name" name="name" value="<?php echo e($student->name); ?>" required>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Roll</label>
                                <input type="text" class="form-control" placeholder="Roll" name="roll" value="<?php echo e($student->roll); ?>" required>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Reg. No</label>
                                <input type="text" class="form-control" placeholder="Reg. No" name="reg_no" value="<?php echo e($student->reg_no); ?>" required>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Department</label>
                                <input type="text" class="form-control" placeholder="Department" name="department" value="<?php echo e($student->department); ?>" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <button class="btn btn-primary" style="margin-top:10px;" type="submit">Submit form</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end validation form -->
        <!-- ============================================================== -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>