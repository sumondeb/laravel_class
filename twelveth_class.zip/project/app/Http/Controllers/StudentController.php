<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student;
use DB;
use Validator;

class StudentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(Request $request){
        $data["perPage"] = $request->input("perPage", 10);
        $data["page"] = $request->input("page", 1);
        $data["search"] = $search = $request->search;

        $data["students"] = Student::join("department", "students.dept_id", "=", "department.id")
            ->select("students.*", "department.dept_name")
            ->when($search, function($query) use ($search){
                $query->where("students.name", "LIKE", "%{$search}%")
                    ->orWhere("students.roll", "LIKE", "%{$search}%")
                    ->orWhere("students.email", "LIKE", "%{$search}%")
                    ->orWhere("department.dept_name", "LIKE", "%{$search}%");
            })
            ->paginate($data["perPage"]);

    	return view("student.index", $data);
    }

    //For Ajax
    public function indexAjax(Request $request){
        return view("student.ajax.index");
    }

    public function indexAjaxData(Request $request){
        $data["perPage"] = $request->input("perPage", 10);
        $data["page"] = $request->input("page", 1);
        $data["search"] = $search = $request->search;
        //Sorting
        $data["sorting"] = $sorting = $request->sorting;
        $data["sortingOrder"] = $sortingOrder = $request->sortingOrder;
        $fields = ["name", "roll", "email", "dept_name"];
        $sortingField = ($sorting>0) ? $fields[$sorting-1] : "id";
        $sortingOrder = ($sortingOrder=="asc") ? "asc" : "desc";

        $data["students"] = Student::join("department", "students.dept_id", "=", "department.id")
            ->select("students.*", "department.dept_name")
            ->when($search, function($query) use ($search){
                $query->where("students.name", "LIKE", "%{$search}%")
                    ->orWhere("students.roll", "LIKE", "%{$search}%")
                    ->orWhere("students.email", "LIKE", "%{$search}%")
                    ->orWhere("department.dept_name", "LIKE", "%{$search}%");
            })
            ->orderBy($sortingField, $sortingOrder)
            ->paginate($data["perPage"]);

        return view("student.ajax.indexAjaxData", $data);
    }

    public function create(){
    	return view("student.create");
    }

    /*public function store(Request $request){
    	$name = $request->name;
    	$roll = $request->roll;
        $reg_no = $request->reg_no;
    	$email = $request->email;
    	$department = $request->department;

        $validation = $request->validate([
            "name" => "required",
            "roll" => "required|numeric",
            "reg_no" => "required|numeric",
            "email" => "required|email",
            "department" => "required",
        ]);

        if($validation->fails()) {
            return redirect('student/create')
                ->withErrors($validation)
                ->withInput();
        } else {
            Student::create([
                "name" => $name,
                "roll" => $roll,
                "reg_no" => $reg_no,
                "department" => $department
            ]);

            return redirect('student');
        }
    }*/

    public function store(Request $request){
    	$data = $request->all();

        $rules = [
            "name" => "required",
            "roll" => "required|numeric",
            "reg_no" => "bail|numeric|min:5|required",
            "email" => "required|email",
            "department" => "required",
        ];

        $msg = [
            'required' => 'The :attribute required.',
            'numeric' => 'The :attribute numeric.',
        ];

        /*$msg = [
            "name" => "The Name",
            "roll" => "The roll",
            "reg_no" => "The reg_no",
            "email" => "The email",
            "department" => "The department"
        ];*/

        $validator = Validator::make($data, $rules, $msg);

        if($validator->fails()) {
            return redirect('student/create')
                ->withErrors($validator)
                ->withInput();
        } else {
            Student::create($data);
        }

    	return redirect('student');
    }

    /*public function store(Request $request){
    	$name = $request->name;
    	$roll = $request->roll;
    	$reg_no = $request->reg_no;
    	$department = $request->department;

    	DB::table("student")->insert([
    		"name" => $name,
    		"roll" => $roll,
    		"reg_no" => $reg_no,
    		"department" => $department
    	]);

    	return redirect('student');
    }*/

    public function edit($id) {
    	//$data["student"] = Student::where("id", $id)->first();
    	$data["student"] = Student::find($id);

    	return view("student.edit", $data);
    }

    public function update(Request $request, $id){
    	$name = $request->name;
    	$roll = $request->roll;
    	$reg_no = $request->reg_no;
    	$department = $request->department;

    	Student::find($id)->update([
    		"name" => $name,
    		"roll" => $roll,
    		"reg_no" => $reg_no,
    		"department" => $department
    	]);

    	return redirect('student');
    }

    public function destroy($id){

    	Student::find($id)->delete();

    	return redirect('student');
    }

}
