<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class StudentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	for($i=1; $i<=100; $i++) {
    		DB::table("students")->insert([
	        	"name" => Str::random(5),
	        	"roll" => Str::random(4),
	        	"email" => Str::random(6)."@gmail.com",
	        	"dept_id" => rand(1,10),
	        	"password" => bcrypt(Str::random(6))
	        ]);
    	}
    }
}
