<p>Hello {{$student->name}},</p><br>
<p>Welcome to Student Panel</p>
