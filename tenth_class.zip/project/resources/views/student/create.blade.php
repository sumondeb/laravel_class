<?php
// echo "<pre>";
// print_r($errors->name);
//die();
/*echo "<pre>";
$errors->get('name');
die();*/
?>

@extends("app")

@section("content")
<div class="container-fluid  dashboard-content">
    <!-- ============================================================== -->
    <!-- pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- ============================================================== -->
        <!-- validation form -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Student Form</h5>
                <div class="card-body">

                    <!-- @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif -->
                    <form method="POST" action="{{route('student.store')}}">
                        @csrf
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Name</label>
                                <input type="text" class="form-control" placeholder="Name" name="name" value="">
                                @if($errors->has('name'))
                                <div class="alert alert-danger" style="margin-top:5px;">
                                    <ul>
                                        @foreach ($errors->get('name') as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                            </div>
                            
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Roll</label>
                                <input type="text" class="form-control" placeholder="Roll" name="roll" value="">
                                @if($errors->has('name'))
                                <div class="alert alert-danger" style="margin-top:5px;">
                                    <ul>
                                        @foreach ($errors->get('roll') as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                            </div>
                            
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Reg. No</label>
                                <input type="text" class="form-control" placeholder="Reg. No" name="reg_no" value="">
                                @if($errors->has('reg_no'))
                                <div class="alert alert-danger" style="margin-top:5px;">
                                    <ul>
                                        @foreach ($errors->get('reg_no') as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                            </div>
                            
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Email</label>
                                <input type="text" class="form-control" placeholder="Email" name="email" value="">
                                @if($errors->has('email'))
                                <div class="alert alert-danger" style="margin-top:5px;">
                                    <ul>
                                        @foreach ($errors->get('email') as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <label for="validationCustom01">Department</label>
                                <input type="text" class="form-control" placeholder="Department" name="department" value="">
                                @if($errors->has('department'))
                                <div class="alert alert-danger" style="margin-top:5px;">
                                    <ul>
                                        @foreach ($errors->get('department') as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <button class="btn btn-primary" style="margin-top:10px;" type="submit">Submit form</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end validation form -->
        <!-- ============================================================== -->
    </div>
</div>
@endsection