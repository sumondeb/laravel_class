<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
	public function index(){
		return view("abc");
	}

	/*public function studentInfo(Request $request, $id){
		$param = $request->param;
		$student = $request->input($param, "ABC");
		$roll = $request->get("roll", 1);

		echo "ID: " . $id . '<br>';
		echo "Parameter: " . $param . '<br>';
		echo "Name: " . $student . '<br>';
		echo "Roll: " . $roll;
	}*/

	public function studentInfo(Request $request, $id){
		$data = $request->except('param');

		echo '<pre>';
		print_r($data);
	}


}