<style type="text/css">
	table {
		border: 2px solid #ccc;
	}
	table th, table td {
		border: 1px solid #ccc;
	}
</style>

<?php echo e($page_title); ?>


<br>
<br>
<a href="<?php echo e(route('studentAdd')); ?>"><button>Add New</button></a>
<br>
<br>
<form>
<table>
	<tr>
		<td><b>Name</b></td>
		<td><input type="text" name="name"></td>
	</tr>
	<tr>
		<td><b>Roll</b></td>
		<td><input type="text" name="roll"></td>
	</tr>
	<tr>
		<td rowspan="2"><button>Submit</button></td>
	</tr>
</table>
</form>
