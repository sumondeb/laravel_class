<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentController extends Controller
{
	public function index(Request $request){
		$data["page_title"] = "Student Info";
		$data["student"] = [
			(object)[
				"id" => 1,
				"name" => "Mr A",
				"roll" => "123"
			],
			(object)[
				"id" => 2,
				"name" => "Mr B",
				"roll" => "124"
			],
			(object)[
				"id" => 3,
				"name" => "Mr C",
				"roll" => "125"
			],
		];

		return view("student.index", $data);
	}

	public function show($id){
		
	}

	public function create(){
		$data["page_title"] = "Student Create";
		return view("student.create", $data);
	}

	public function store(Request $request){
		
	}

	public function edit($id){
		
	}

	public function update(Request $request, $id){
		
	}

	public function destroy($id){
		
	}

}