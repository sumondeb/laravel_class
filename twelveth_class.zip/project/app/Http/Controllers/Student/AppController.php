<?php

namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;
use Auth;
use Validator;
use Mail;
use App\Model\Student;

class AppController extends Controller
{
	/*public function __construct()
    {
        $this->middleware('auth');
    }*/
    
    public function dashboard(){
    	return view("studentPanel.dashboard");
    }

    public function register(){
    	$data["departments"] = DB::table("department")->orderBy("dept_name", "asc")->get();
    	return view("studentPanel.register", $data);
    }

    public function registerAction(Request $request){
    	$name = $request->name;
    	$roll = $request->roll;
    	$department = $request->department;
    	$email = $request->email;
    	$password = $request->password;

    	$validator = Validator::make($request->all(), [
            'name' => 'required',
            'roll' => 'required',
            'department' => 'required',
            'email' => 'required|email|unique:students',
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect(route('student.register'))
                        ->withErrors($validator)
                        ->withInput();
        } else {
        	//$student_id = DB::table("students")->insertGetId([
        	Student::create([
        		"name" => $name,
        		"roll" => $roll,
        		"dept_id" => $department,
        		"email" => $email,
        		"password" => bcrypt($password)
        	]);

        	$student_id = Student::orderBy("id", "desc")->first()->id;

        	Auth::guard("student")->loginUsingId($student_id);

        	return redirect(route("student.dashboard"));
        }
    }

    public function login(Request $request){
    	$data["errMsg"] = $request->session()->get("errMsg", "");
    	return view("studentPanel.login", $data);
    }

    public function loginAction(Request $request){
    	$email = $request->email;
    	$password = $request->password;
    	$remember = $request->remember;
    	$remember = ($remember==1) ? true : false;

    	$validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect(route('student.login'))
                        ->withErrors($validator)
                        ->withInput();
        } else {
        	if(Auth::guard("student")->attempt(["email"=>$email, "password"=>$password], $remember)) {
        		return redirect(route("student.dashboard"));
        	} else {
        		return redirect(route('student.login'))
        				->with("errMsg", "User or Password is wrong")
                        ->withInput();
        	}
        }
    }

    public function logout(){
    	Auth::guard("student")->logout();
    	return redirect(route("student.login"));
    }

    public function passwordReset(){
    	return view("studentPanel.passwordReset");
    }

    public function passwordResetAction(Request $request){
    	$email = $request->email;

    	$validator = Validator::make($request->all(), [
            'email' => 'required|email'
        ]);

        if ($validator->fails()) {
            return redirect(route('student.password.request'))
                        ->withErrors($validator)
                        ->withInput();
        } else {
        	$student = Student::where("email", $email)->first();
        	if(empty($student)) {
        		return redirect(route('student.password.request'))
        				->with("msg", "Email doesn't exist")
        				->with("msgType", "danger")
                        ->withInput();
        	} else {
        		$password = uniqid();
        		$student->update([
        			"password" => bcrypt($password)
        		]);

        		//Mail
        		$data["student"] = $student;
        		$data["password"] = $password;
        		Mail::send('emails.passwordReset', $data, function ($m) use ($student) {
                    $m->from('rubel66n@gmail.com', 'Mubarok Hossain');
                    $m->to($student->email, $student->name)->subject('Registration Confirmation');
                });

        		return redirect(route('student.password.request'))
        				->with("msg", "Mail has been sent")
        				->with("msgType", "success")
                        ->withInput();
        	}
        }
    }

}
