<?php $__env->startSection("content"); ?>
<div class="container-fluid  dashboard-content">
    <!-- ============================================================== -->
    <!-- pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <h2 class="pageheader-title" style="display: inline;">Students</h2>
                <a href="<?php echo e(route('student.create')); ?>"><button class="btn btn-primary" style="float: right;">Add New</button></a>
                <select id="perPage" class="btn btn-info" style="float: right; margin-right:5px;">
                    <option value="10" selected=1">10</option>
                    <option value="20">20</option>
                    <option value="30">30</option>
                    <option value="40">40</option>
                    <option value="50">50</option>
                </select>
                <span style="float: right; margin-right:15px;">
                    <input type="text" id="search" class="form-control" style="display: inline; width: 150px;" placeholder="Search">
                </span>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end pageheader -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- ============================================================== -->
        <!-- basic table  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Student List</h5>
                <div class="card-body">
                    <div class="table-responsive" id="ajax-data">

                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end data table multiselects  -->
        <!-- ============================================================== -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("javascript"); ?>
<script type="text/javascript">
    $(document).ready(function(){
        searchData();

        $("#search").keyup(function(){
            searchData();
        });

        $("#perPage").change(function(){
            searchData();
        });

        $("#ajax-data").on("click", ".page-link", function(event){
            event.preventDefault();
            var url = $(this).attr("href");
            searchData(url);
        });

        $("#ajax-data").on("click", ".sorting", function(){
            var sortingClass = ($(this).hasClass("sorting_asc")) ? "sorting_desc" : "sorting_asc";

            $(".sorting").removeClass("sorting_asc");
            $(".sorting").removeClass("sorting_desc");
            $(this).addClass(sortingClass);
            
            searchData();
        });

    });

    function searchData(url="<?php echo e(route('student-ajax-data')); ?>"){
        var search = $("#search").val();
        var perPage = $("#perPage").val();
        //Sorting
        if($(".sorting_asc").length>0) {
            var sorting = $(".sorting_asc").attr("sorting");
            var sortingOrder = "asc";
        } else if($(".sorting_desc").length>0) {
            var sorting = $(".sorting_desc").attr("sorting");
            var sortingOrder = "desc";
        } else {
            var sorting = 0;
            var sortingOrder = "";
        }

        $.ajax({
            url: url,
            data: {
                search:search,
                perPage:perPage,
                sorting:sorting,
                sortingOrder:sortingOrder
            },
            method: "get",
            dataType: "html",
            success: function(data){
                $("#ajax-data").html(data);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>