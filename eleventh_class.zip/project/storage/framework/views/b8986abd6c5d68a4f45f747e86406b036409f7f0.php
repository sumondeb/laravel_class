<?php
	$pageStart = $paginator->currentPage()-2;
	$pageStart = ($pageStart>0) ? $pageStart : 1;

	$pageEnd = $paginator->currentPage()+2;
	$pageEnd = ($pageEnd>$paginator->lastPage()) ? $paginator->lastPage() : $pageEnd;
?>
<ul class="pagination" role="navigation">

	<li class="page-item" aria-label="« Previous">
		<?php if($paginator->currentPage()==1): ?>
		<span class="page-link">‹‹</span>
		<?php else: ?>
		<a class="page-link" href="<?php echo e($paginator->url(1)); ?>" rel="previous" aria-label="« Previous">‹‹</a>
		<?php endif; ?>
	</li>
        
	<li class="page-item" aria-label="« Previous">
		<?php if($paginator->currentPage()==1): ?>
		<span class="page-link">‹</span>
		<?php else: ?>
		<a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="previous" aria-label="« Previous">‹</a>
		<?php endif; ?>
	</li>

	<?php for($i=$pageStart; $i<=$pageEnd; $i++): ?>
	<?php if($paginator->currentPage()==$i): ?>
	<li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($i); ?></span></li>
	<?php else: ?>
	<li class="page-item" aria-current="page"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a></li>
	<?php endif; ?>
	<?php endfor; ?>

	<li class="page-item">
		<?php if($paginator->currentPage()==$paginator->lastPage()): ?>
		<span class="page-link">›</span>
		<?php else: ?>
        <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="Next »">›</a>
        <?php endif; ?>
    </li>

    <li class="page-item">
		<?php if($paginator->currentPage()==$paginator->lastPage()): ?>
		<span class="page-link">›</span>
		<?php else: ?>
        <a class="page-link" href="<?php echo e($paginator->url($paginator->lastPage())); ?>" rel="next" aria-label="Next »">››</a>
        <?php endif; ?>
    </li>
 </ul>