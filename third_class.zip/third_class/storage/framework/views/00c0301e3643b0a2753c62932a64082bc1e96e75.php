<style type="text/css">
	table {
		border: 2px solid #ccc;
	}
	table th, table td {
		border: 1px solid #ccc;
	}
</style>

<?php echo e($page_title); ?>


<br>
<br>
<a href="<?php echo e(route('studentAdd')); ?>"><button>Add New</button></a>
<br>
<br>
<table>
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Roll</th>
	</tr>
	<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($student->id); ?></td>
		<td><?php echo e($student->name); ?></td>
		<td><?php echo e($student->roll); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
