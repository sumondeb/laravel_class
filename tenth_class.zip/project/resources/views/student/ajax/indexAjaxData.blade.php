<table class="table table-striped table-bordered first dataTable">
    <thead>
        <tr>
            <th>Sl</th>
            <th sorting="1" class="sorting @if($sorting==1) {{($sortingOrder=='asc') ? 'sorting_asc' : 'sorting_desc'}} @endif">Name</th>
            <th sorting="2" class="sorting @if($sorting==2) {{($sortingOrder=='asc') ? 'sorting_asc' : 'sorting_desc'}} @endif">Roll</th>
            <th sorting="3" class="sorting @if($sorting==3) {{($sortingOrder=='asc') ? 'sorting_asc' : 'sorting_desc'}} @endif">Email</th>
            <th sorting="4" class="sorting @if($sorting==4) {{($sortingOrder=='asc') ? 'sorting_asc' : 'sorting_desc'}} @endif">Derpartment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        @php $sl=(($page-1)*$perPage)+1; @endphp
        @foreach($students as $student)
        <tr>
            <td>{{$sl++}}</td>
            <td>{{$student->name}}</td>
            <td>{{$student->roll}}</td>
            <td>{{$student->email}}</td>
            <td>{{$student->department_name}}</td>
            <td><a href="{{route('student.edit', $student->id)}}"><button class="btn btn-info">Edit</button></a> | <form style="display: inline;" method="post" action="{{route('student.delete', $student->id)}}">@csrf <button class="btn btn-danger">Delete</button></form></td>
        </tr>
        @endforeach
    </tbody>
</table>
<div style="margin-top: 10px;" id="pagination">
    {{$students->links('paginate')}}
</div>