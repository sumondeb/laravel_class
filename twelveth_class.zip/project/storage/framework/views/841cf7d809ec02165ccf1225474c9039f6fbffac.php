<p>Hello <?php echo e($student->name); ?>,</p><br>
<p>Your Credential:</p><br>
<p>User: <?php echo e($student->email); ?></p><br>
<p>Password: <?php echo e($password); ?></p><br>
