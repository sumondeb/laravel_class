<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Route::middleware('auth')->group(function () {
Route::group(['middleware' => ['auth']], function () {
	Route::get('/', 'AppController@dashboard')->name('dashboard');
	Route::get('home', 'AppController@dashboard')->name('dashboard');

	Route::get('student', 'StudentController@index')->name('student');

	Route::get('student-ajax', 'StudentController@indexAjax')->name('student-ajax');
	Route::get('student-ajax-data', 'StudentController@indexAjaxData')->name('student-ajax-data');

	Route::get('student/create', 'StudentController@create')->name('student.create');
	Route::post('student', 'StudentController@store')->name('student.store');

	Route::get('student/{id}/edit', 'StudentController@edit')->name('student.edit');
	Route::post('student/{id}', 'StudentController@update')->name('student.update');

	Route::post('student/{id}/delete', 'StudentController@destroy')->name('student.delete');
});

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');

Route::group(['as' => "student.", "prefix" => "student-panel", "namespace" => "Student"], function () {
	Route::get('login', 'AppController@login')->name('login');
	Route::post('login', 'AppController@loginAction')->name('login');
	Route::get('register', 'AppController@register')->name('register');
	Route::post('register', 'AppController@registerAction')->name('register');

	Route::get('logout', 'AppController@logout')->name('logout');

	Route::get('password/reset', 'AppController@passwordReset')->name('password.request');
	Route::post('password/reset', 'AppController@passwordResetAction')->name('password.request');

	Route::group(['middleware' => "studentAuth"], function () {
		Route::get('/', 'AppController@dashboard')->name('dashboard');
	});
});
