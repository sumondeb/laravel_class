<p>Hello {{$student->name}},</p><br>
<p>You have request to reset your password.</p><br>
<p>Password Reset Link:</p><br>
<p><a href="{{$link}}" target="_blank">Reset Your Password</a></p><br>
