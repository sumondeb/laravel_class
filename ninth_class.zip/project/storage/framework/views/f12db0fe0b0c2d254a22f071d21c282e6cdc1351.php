<table class="table table-striped table-bordered first">
    <thead>
        <tr>
            <th>Sl</th>
            <th>Name</th>
            <th>Roll</th>
            <th>Email</th>
            <th>Derpartment</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $sl=(($page-1)*$perPage)+1; ?>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($sl++); ?></td>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->roll); ?></td>
            <td><?php echo e($student->email); ?></td>
            <td><?php echo e($student->department_name); ?></td>
            <td><a href="<?php echo e(route('student.edit', $student->id)); ?>"><button class="btn btn-info">Edit</button></a> | <form style="display: inline;" method="post" action="<?php echo e(route('student.delete', $student->id)); ?>"><?php echo csrf_field(); ?> <button class="btn btn-danger">Delete</button></form></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div style="margin-top: 10px;" id="pagination">
    <?php echo e($students->links('paginate')); ?>

</div>