<p>Hello {{$student->name}},</p><br>
<p>Your Credential:</p><br>
<p>User: {{$student->email}}</p><br>
<p>Password: {{$password}}</p><br>
