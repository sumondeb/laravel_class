<?php
	$pageStart = $paginator->currentPage()-2;
	$pageStart = ($pageStart>0) ? $pageStart : 1;

	$pageEnd = $paginator->currentPage()+2;
	$pageEnd = ($pageEnd>$paginator->lastPage()) ? $paginator->lastPage() : $pageEnd;
?>
<ul class="pagination" role="navigation">

	<li class="page-item" aria-label="« Previous">
		@if($paginator->currentPage()==1)
		<span class="page-link">‹‹</span>
		@else
		<a class="page-link" href="{{$paginator->url(1)}}" rel="previous" aria-label="« Previous">‹‹</a>
		@endif
	</li>
        
	<li class="page-item" aria-label="« Previous">
		@if($paginator->currentPage()==1)
		<span class="page-link">‹</span>
		@else
		<a class="page-link" href="{{$paginator->previousPageUrl()}}" rel="previous" aria-label="« Previous">‹</a>
		@endif
	</li>

	@for($i=$pageStart; $i<=$pageEnd; $i++)
	@if($paginator->currentPage()==$i)
	<li class="page-item active" aria-current="page"><span class="page-link">{{$i}}</span></li>
	@else
	<li class="page-item" aria-current="page"><a class="page-link" href="{{$paginator->url($i)}}">{{$i}}</a></li>
	@endif
	@endfor

	<li class="page-item">
		@if($paginator->currentPage()==$paginator->lastPage())
		<span class="page-link">›</span>
		@else
        <a class="page-link" href="{{$paginator->nextPageUrl()}}" rel="next" aria-label="Next »">›</a>
        @endif
    </li>

    <li class="page-item">
		@if($paginator->currentPage()==$paginator->lastPage())
		<span class="page-link">›</span>
		@else
        <a class="page-link" href="{{$paginator->url($paginator->lastPage())}}" rel="next" aria-label="Next »">››</a>
        @endif
    </li>
 </ul>