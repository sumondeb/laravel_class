<style type="text/css">
	table {
		border: 2px solid #ccc;
	}
	table th, table td {
		border: 1px solid #ccc;
	}
</style>

{{$page_title}}

<br>
<br>
<a href="{{route('studentAdd')}}"><button>Add New</button></a>
<br>
<br>
<table>
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Roll</th>
	</tr>
	@foreach($student as $student)
	<tr>
		<td>{{$student->id}}</td>
		<td>{{$student->name}}</td>
		<td>{{$student->roll}}</td>
	</tr>
	@endforeach
</table>
