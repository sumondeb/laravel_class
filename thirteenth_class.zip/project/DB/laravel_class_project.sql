-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2019 at 03:17 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel_class_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `dept_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `dept_name`) VALUES
(1, 'a'),
(2, 'O5amhehpY0'),
(3, 'c504IVjO8z'),
(4, 'o3aZPW5ERb'),
(5, 'hAFN2wS5Jl'),
(6, 'tEsclvA23c'),
(7, 'IYsY1IHRvH'),
(8, '2aGiIdnfa0'),
(9, 'SVTHV6PVKK'),
(10, 'e2qR4jJv8r'),
(11, 'YLwBEobRt1'),
(12, 'YXD3i2i7jN');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_students_table', 1),
(2, '2014_10_12_000000_create_users_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_02_17_123727_create_customers_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roll` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dept_id` int(11) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `roll`, `email`, `dept_id`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'TBhoe', 'SfjH', 'O4Ffwl@gmail.com', 1, '$2y$10$EU2M10gDpqhZGr/FBktwuuRm9Zl3wVWyAltL5DB0DkiMVPWn9QDyS', NULL, NULL, NULL),
(2, 'SJAEZ', 'uccR', 'xg5B2F@gmail.com', 7, '$2y$10$wzzJsr98u49wUg55CeKiz.nBo0IwmU1OltcM3xerlbaSnvwi1Nq8e', NULL, NULL, NULL),
(3, 'kffhH', '2Dbd', 'XUYBPp@gmail.com', 6, '$2y$10$reccaFs0nSzlInEMOcR1KeO6VeKj8POBUK9cJS6VwKACRMeyKU2ey', NULL, NULL, NULL),
(4, 'i5xuI', 'LU70', '9aumpT@gmail.com', 4, '$2y$10$2nXN2VP8AkwpT7//XlulPOdTI025veIyZSmNi8l3QPeK2o1vTwsYq', NULL, NULL, NULL),
(5, 'S4wCY', 'tdA3', 'iFzkDr@gmail.com', 5, '$2y$10$H7IZGC5ZQ41B23ve0UrrZOZDR7sm7pKG92moCjmHYbqM/b6gEbbp2', NULL, NULL, NULL),
(6, 'mve1x', 'Vlyr', 'd16OLc@gmail.com', 10, '$2y$10$NFRY1wRX63mwMuA.kTFRoO39vBwNNxRA0LK3yXiGu22dCaYPqM9By', NULL, NULL, NULL),
(7, 'lsT9O', 'sRjV', 'OU20pD@gmail.com', 2, '$2y$10$XfU70AJVNcSgYyIPDlRDmuaaUhNuBebXklkoxPgBwmVUBXszGEqk.', NULL, NULL, NULL),
(8, 'A9T63', '89Jz', 'jVU9cW@gmail.com', 1, '$2y$10$KOc/bbo7WD0bN86CM.8Y9.l8XfE7SJG0IfeP/IV0cH9rmFoP0ue3m', NULL, NULL, NULL),
(9, 'FH3hl', 'OBR3', 'cqNPIn@gmail.com', 4, '$2y$10$G3lRKbypCMv3jJxP3m2ZH.xsChLUJQOTzKO64Lt1h8havyk8snZKi', NULL, NULL, NULL),
(10, 'f4631', 'M7wg', 'ZQOCBI@gmail.com', 3, '$2y$10$qdUdhnkD4BpTdN3cWNYz3uEBNz.lxCrxNXDgZCaqaA2doejMF7J3i', NULL, NULL, NULL),
(11, 'OzizA', 'jjMI', 'RDdfyH@gmail.com', 5, '$2y$10$RxUV8H7r9CHdilgsHUH3o.ZGA6yLMoZ8gmYtyXXuaDZNGg9h/r92G', NULL, NULL, NULL),
(12, 'NQTJl', 'TXBZ', 'sPBO6a@gmail.com', 10, '$2y$10$8TMgh6qd/X0vROuvk/zbz.sS2Bl1l.2YxSLICXzkiBWBURphSHC5u', NULL, NULL, NULL),
(13, 'OVmRx', 'GkPI', 'J3QKG9@gmail.com', 10, '$2y$10$RwsqQ.TCYC2vmABXWT7YxOZvd/QuoMvY/fFdk4eEK29QOo6KZazeK', NULL, NULL, NULL),
(14, 'mKL6O', 'gAYr', 'nmVu7Q@gmail.com', 8, '$2y$10$xZxMMlyLx.xGAgm8SC.co.bl3u4N9pAvkUmKJBcNoyXshvYfJsd82', NULL, NULL, NULL),
(15, 'OttS4', 'ypPp', 'czFZf7@gmail.com', 3, '$2y$10$QMuE2dt0M/gEx/OT8Gv4MOpxULv9poMcUy1w8zhrZm2IIICuKCUaS', NULL, NULL, NULL),
(16, 'yYCuv', 'YzlV', '8vbMF1@gmail.com', 5, '$2y$10$0z4EXHKUHAOVpmojsq11M.v7Unn.RKIpgWqUYphwjuwKw3isEAaWO', NULL, NULL, NULL),
(17, 'oMoYt', '5AvW', '3BzMTl@gmail.com', 7, '$2y$10$str/hAb6EjYf3LI4z8TKJuMEjRczZn89H.QOw8OgI5I8fDqOZgTtS', NULL, NULL, NULL),
(18, 'D1xhi', 'mi9B', 'nTuayj@gmail.com', 3, '$2y$10$A9tYJTblIJDraX20vXYMOeK9lSsfIg1yhofrsgzwq/zDaGxjDX/Fe', NULL, NULL, NULL),
(19, 'TAEeR', 'UhmB', 'GMTcEw@gmail.com', 5, '$2y$10$MdZAEUmCyGzrk2LylQ9NrenaoW40ZwoFepb57i.mTRgV7XTFpgyoW', NULL, NULL, NULL),
(20, 'ZrhHH', 'MU29', 'hREPQA@gmail.com', 9, '$2y$10$9.WZ0c8.6Pc1p2sHewqi9eCsAGIX19cCFq1Y7A/ghp.tfh32kdcsO', NULL, NULL, NULL),
(21, 'Ha72J', 'UVzS', '7KZgqv@gmail.com', 1, '$2y$10$88wb10TMB21wZNuOH0eUx.KdoYedpU0HAJdjj7V1QYKvPmXvCW1/2', NULL, NULL, NULL),
(22, 'x9Wl6', 'ypzs', '0hAAsy@gmail.com', 5, '$2y$10$LoFfV/J2Li4b4nzVYluSKuBiJTGhGy1e/rVj61SEUSaJO170gN.tu', NULL, NULL, NULL),
(23, 'cTebf', 'q9d9', 'T3dcZS@gmail.com', 1, '$2y$10$Ubm.DgwT66N4lO6W0eMW2.LH7qIPyQVclMXN8t6u1f33b1xzMm9MC', NULL, NULL, NULL),
(24, 'Rra0X', '4P71', 'Y933jW@gmail.com', 10, '$2y$10$hltw9syLwbXUfr3qi9YBbeXmUiUXqjsaxVcSCRiniiSLbOUfWLYeO', NULL, NULL, NULL),
(25, 'a4mfU', 'P7qQ', 'oQFEQG@gmail.com', 4, '$2y$10$nB3eS7Qn/MktPHm4bLPyy..8PUDUgeSy/7vzIoe10nbpjX5UOmjzm', NULL, NULL, NULL),
(26, 'AYpXm', 'kHsr', '5rFo42@gmail.com', 10, '$2y$10$3BG6/pPdiLOqMDclawBO8.hT92lL73Z/L69Md9MBFfP.cKFPLbm2a', NULL, NULL, NULL),
(27, 'EJYcj', 'mA3P', 'GdunmO@gmail.com', 9, '$2y$10$.w8Sj.ekHeoguxHLAmYmO.10I0gsnZvVJx9uKEKPbW2.ym3NfnQXy', NULL, NULL, NULL),
(28, 'H3o7l', 'uoiQ', 'Lg2llj@gmail.com', 7, '$2y$10$8Iz9qOlAnnWah5ofXFzRGuVenouwFtqo5KS6M3RONFkeqbJ.wInri', NULL, NULL, NULL),
(29, '7J1Ba', 'M05N', 'uBaf1r@gmail.com', 3, '$2y$10$vMJyPg/bfsblHqXuxhuN1u9BcNSbhAvKaKKgs0VJLPcbzNaJzzUFK', NULL, NULL, NULL),
(30, 'TEU11', 'bl9x', 'AMtrNP@gmail.com', 1, '$2y$10$jzZSRIMASdHbjyKQR0KjouSq5m6qdddhwEmxsSLVKRxq0aL78WmQe', NULL, NULL, NULL),
(31, '9osIN', 'yFxW', 'eJWpLG@gmail.com', 2, '$2y$10$UCcNwPaFypaPQz2suOlt8udvvfJz/xZ2z4Drdjne0c24zx89Ze5aG', NULL, NULL, NULL),
(32, '7xOqi', 'cnem', 'zSvNj6@gmail.com', 6, '$2y$10$zBQyXbsVSJaw.lxQhetR7.qcI3x8upvO77708e4DDQkP95TBAlHYC', NULL, NULL, NULL),
(33, 'paYez', 'r3WQ', 'zqOmoN@gmail.com', 7, '$2y$10$ZZEY4KBtW7wdip2bQXfqUuB9VKVuTqYqxXmZsmbhJbc54.zXMitMS', NULL, NULL, NULL),
(34, 'vXynG', 'x1FH', 'Ia7zNy@gmail.com', 1, '$2y$10$oC6M.Aiow/arBZO5BwZH9.aXcLL3xn.4UOZhErxpGT4ok5HlF8QTu', NULL, NULL, NULL),
(35, 'yLtYp', 'tj1x', 'dg9yWA@gmail.com', 8, '$2y$10$diD1VXk2M2kEylZCoMBBB.SC1eQtJb.xaJWI7lYefiPa5ZLMHvU5y', NULL, NULL, NULL),
(36, 'Ql1gr', 'E4Y0', 'Mdy5dE@gmail.com', 1, '$2y$10$N6D8mNAPyTqmMoP//q1tIuIkHcDDuMmFdoKPwKpwMi61Q7v3SkPma', NULL, NULL, NULL),
(37, '3FN0D', '1sqz', 'xnfe9E@gmail.com', 9, '$2y$10$RgObKuquvPdRsVIR4K3WhuUPTRRKjM.xdkr6qO3fswBK4nFU2U2Tq', NULL, NULL, NULL),
(38, 'OPL1C', '4XEI', 'vvLusu@gmail.com', 4, '$2y$10$jJPeUWDXQbxhz2VllU0n3uJ87R2FVJdeX4dji4zYTIW8Ls0OyzAiu', NULL, NULL, NULL),
(39, 'TpoZP', '3I0Z', 'hVfjx6@gmail.com', 3, '$2y$10$.Ih9ITRnUwMWLDx8jPXWYuV2pSUIW880xhQsOly.HsFrBrFAae1vK', NULL, NULL, NULL),
(40, 'H0T3z', '8ox3', 'zLokHo@gmail.com', 9, '$2y$10$39gtNAHiOeMg0aHuD4yh4.CmuPmQk70tLNw3S3PYUM96rzi7Ic8yK', NULL, NULL, NULL),
(41, 'BgSSF', '19MQ', 'ZL9dYK@gmail.com', 3, '$2y$10$CpYhEJn7wSbMY5x90OfspeQUWgutVtujL4j8Aj6y78wWKTLf/IaDq', NULL, NULL, NULL),
(42, '059yJ', 'PIrD', 'W4M4Qh@gmail.com', 5, '$2y$10$xOOe8EOquUyfJYsMT0qYKuKJxv4StmaXHnR6yS5N5zq7v5ERPHN1.', NULL, NULL, NULL),
(43, 'CZnUj', '2ziu', 'LdOjX9@gmail.com', 10, '$2y$10$Lou8G.iGUJD/O71HwqBqPesv0ZPfRrNWyM.zWGeAmbraA4l7ZUFM.', NULL, NULL, NULL),
(44, 'QotRY', 'gC79', 'wIMCcj@gmail.com', 3, '$2y$10$zPaLC1IOwByP6yC0FQEkruhXPyfXoGIBllF1AkllpF0blBFmltA5m', NULL, NULL, NULL),
(45, '63q70', 'pqMM', 'voKmcU@gmail.com', 3, '$2y$10$UoYg3t0ZONZCeRvOx0t02eP1GyBojGYiURm2hVVxjNQ6vJ51qG3sC', NULL, NULL, NULL),
(46, 'pxEPV', 'QNlx', '6IEr9T@gmail.com', 4, '$2y$10$BpBodapVd8xDzEtHxN3HJ.GKWQKnGeHx/gbQTB7WTr2Fa.8.kp4CG', NULL, NULL, NULL),
(47, 'ln5xB', '4X8Y', 'ugqJKG@gmail.com', 3, '$2y$10$0zcT/sn2UUweJ6DwIVX8Hep1OaBOm6LmfjlATS9PZQJ2z4p/ex2Pu', NULL, NULL, NULL),
(48, 'LbylD', 'Fyqy', 'Q6i4qe@gmail.com', 1, '$2y$10$csV5KC07PN3o/hkPd2o1juKfg1Or9F1It/03aJDqQ0eyF5AZSk3Im', NULL, NULL, NULL),
(49, 'mvG6M', 'sKlB', 'RjUPeB@gmail.com', 6, '$2y$10$p4LB0LiiOqevV19XhFr/u.Y0OeGCLSA1euCJXu.Dw1oLUssbzgSPK', NULL, NULL, NULL),
(50, 'fA7HT', 'IIhL', 'VVFwaE@gmail.com', 4, '$2y$10$IEztLphW/Xyx.TZsNSbzR.PczQLkwYpa1ktOgzcKuhWdAzI5lQwqC', NULL, NULL, NULL),
(51, '3bnTT', '645q', 'VNFwxW@gmail.com', 2, '$2y$10$7TBKBcIIVuaTf4QM.CiwseHN/kTKktgYViTg4K26CUzRAltDuoODK', NULL, NULL, NULL),
(52, 'KRXNI', 'N6Dl', 'a1LxaQ@gmail.com', 5, '$2y$10$lM5ran4SDSu.VBv3VCldheJ6xnnQlpNIvDWSHC77ktmzjt4o14NGO', NULL, NULL, NULL),
(53, 'idS2l', 'HvEc', 'hYW0TP@gmail.com', 8, '$2y$10$iMvrtkVhsbK8c7V6uHsB/.kTh0fHdHr706N7w98DAytcX/1pyWw.6', NULL, NULL, NULL),
(54, 'ChFwi', 'VcxX', 'TVFIP9@gmail.com', 6, '$2y$10$vP8bOJD070VNoqzSxzfaS.JuDr8qkVQ1cUjbvMbCGfDyPaETVbhFK', NULL, NULL, NULL),
(55, 'ahCFj', 'QIPH', 'fXChRn@gmail.com', 7, '$2y$10$bPtxrt.vMdGsvKEbjNRUFeufm5JihRQk4zgOP7TjuC0kj.aJXpVsW', NULL, NULL, NULL),
(56, 'uKRXq', 'G4HK', 'F0YRX5@gmail.com', 1, '$2y$10$Po0eMJJKXYWDyaNL1Rt7LOBGZEbpQFwcF5BhUxiNCbyk/yaKJeSme', NULL, NULL, NULL),
(57, 'RnTxP', '9SXx', 'UU5KdR@gmail.com', 7, '$2y$10$5ESoX7cvqXs0p6mN7qU9/.piSBXWrhLHeqIWBPKRPTX1HzUfmyqle', NULL, NULL, NULL),
(58, 's1sda', 'S52z', 'gtCj8E@gmail.com', 6, '$2y$10$xrtJicHEGB4Zo2U.k2qV1Oq0.PQj/1VclkhwjIRvjj8WN7X8fygZK', NULL, NULL, NULL),
(59, 'ITq0A', 'xqij', '92F7JE@gmail.com', 3, '$2y$10$ZdIvJxn8QYwU5waYB5Wxr.ZO/WQgOnJ3Lr6Gyg6Okb2GkZdYZIOsu', NULL, NULL, NULL),
(60, 'wQILU', '9h3o', 'GuEvR0@gmail.com', 7, '$2y$10$GVUHWkwnCeco9As.Eb2.k.R3cMpuWVZWt6j6M6I6yZrW.J2FoCNaW', NULL, NULL, NULL),
(61, 'oI9Yt', 'gdT2', 'nspPJV@gmail.com', 2, '$2y$10$0KbouR9NfwS0zdgzZbWowe8malEWrPlDXsWh5YHByy62bLTbXt6sa', NULL, NULL, NULL),
(62, 'QGCrv', 'kqbT', 'z1JeQ4@gmail.com', 9, '$2y$10$uLcJvtU.xkYbbBf4HNYiMOt/UA2DSTk9sTOkQl635LVIy5nr87lw2', NULL, NULL, NULL),
(63, 'HczWC', 'OXmk', 'MLYAKX@gmail.com', 9, '$2y$10$wtN5NDnq7TLsHnbzSjlB1eJtrtQpVRNdxW.h2/Qe2t0ABM6AS4NcC', NULL, NULL, NULL),
(64, 'HAcx6', 'EzTr', 'xTQqFH@gmail.com', 1, '$2y$10$KUY9SvrhzpMkd40L4v4WWerm1Vz/5oxiFJs/giB0ZnoMDv0FNw1cC', NULL, NULL, NULL),
(65, 'wgx8V', 'WyO0', 'ojXBXP@gmail.com', 3, '$2y$10$i/HeshcQxVdlLZHEPR3DN.2t5xd8aeIP7hn5BE71uXbAD57kqnS4y', NULL, NULL, NULL),
(66, 'p4V2A', 'Zzma', 'LBJhjB@gmail.com', 3, '$2y$10$159j4gEoMLu8nwnpqOFumee2g.8UlQUXSyxM4zDBFlQcyL7wNsDNq', NULL, NULL, NULL),
(67, 'e4vMe', 'EnWo', 'Cr8Pj1@gmail.com', 6, '$2y$10$zm01yThfxrKyuxvVxJuz1On37sCGs4.zQqtEWnXWegExNYIzKag6e', NULL, NULL, NULL),
(68, 'ag0jK', '39CW', 'M22qvK@gmail.com', 10, '$2y$10$YTmFwKFdd8aAyguSAnW5de.u94Vie.jO13VSYTiqNJsLy/H7IZ7a2', NULL, NULL, NULL),
(69, 'cYAcS', 'vfM9', 'A3DnmP@gmail.com', 2, '$2y$10$GEmXa5BAS1eMNjKy8o0Kxu4Izq3W8i7Ox.1te0pdw.ja1wQPlvOtu', NULL, NULL, NULL),
(70, '1Nols', 'j8VV', 'AvU192@gmail.com', 8, '$2y$10$v1UVQj.DXQqsJ0a7z6ONTuTAVNKuTNAZYMMopofRfMLWCkyAeMrBe', NULL, NULL, NULL),
(71, 'gykBv', 'CfSW', 'dcoYCz@gmail.com', 2, '$2y$10$YYjsVoa6HD7VertWcrkCa.IL2iH5YSAamy..01It0p2C7qBydk92m', NULL, NULL, NULL),
(72, '7Oh2b', 'WxMl', 'M0gapZ@gmail.com', 3, '$2y$10$0DGbQc1qIthwPLlty7tLge.Sr9Mwa3Z8azaCkVo8mBI9IVsbiy3I6', NULL, NULL, NULL),
(73, 'TmZtr', 'E1RM', 'jNUPOc@gmail.com', 10, '$2y$10$90K6Jsp4X6PQh3plPsE4w.J8tEOJs7SD2ZjeplAYWkOnq7Q6fUY6K', NULL, NULL, NULL),
(74, 'N6sFR', 'jnGZ', 'CKs2jx@gmail.com', 8, '$2y$10$G9vzgT6bxNiA6QJjb5bHm.Ia5YBtt.bDQrALVMrcozOcAjeO1/fQe', NULL, NULL, NULL),
(75, 'ThX0e', 'L1xb', 'X2Bm5h@gmail.com', 9, '$2y$10$cY9oIX7ynLroKMazbXivzudcab5yar4jgndfY5dCp0xXpxRqUaTBC', NULL, NULL, NULL),
(76, '0oLnT', 'TxdU', 'JAsuRv@gmail.com', 5, '$2y$10$aCMPfYnpgzLkkWMSJl63N.XVEUYkI2j8L3lA5MaHTXHhxpSGGK.Ci', NULL, NULL, NULL),
(77, '9frGN', 'di0i', 'creuW8@gmail.com', 3, '$2y$10$oRSeNW1taRuYY/dJGUc0teQYN3antc2WFh1wtLfGtKxUMFXhgTDw.', NULL, NULL, NULL),
(78, 'MOmpK', '4fe0', 'lfroSs@gmail.com', 1, '$2y$10$PUcj0coXeSUREKM3zOGlYuB05W7sUT8HB/lVkPF84PQQAcSbi/qIO', NULL, NULL, NULL),
(79, 'nSfyf', '6Ugy', 'awD2cT@gmail.com', 9, '$2y$10$HwTpzRgiV0MBv44qKRoOMOQ3Slc.VgP3AoNNgBaTsWzXv0OR.D//K', NULL, NULL, NULL),
(80, 'HUuET', 'gcq0', 'r19BRV@gmail.com', 7, '$2y$10$08CkYo70/ACyZfolTE3FeuP9de03PZ7K6ypLO8z.LgaNAIdpiZVC6', NULL, NULL, NULL),
(81, 'YUL5f', 'QtD0', 'w0nfWi@gmail.com', 2, '$2y$10$vQW1tN4Q7YD7aHuop2GEz.gXGj6/mmCaVLyylnYufrFWR3LBv4.4.', NULL, NULL, NULL),
(82, 'Tu4GC', 'kgzE', 'sFmYyj@gmail.com', 2, '$2y$10$J1xGnYYkhxfrNqUcqy57/eg7g6KAZF1zQGva/wE5EWH9p1q5DQ1M2', NULL, NULL, NULL),
(83, 'zKC1p', 'z6kB', 'KNqKWf@gmail.com', 10, '$2y$10$RKdLplzmxfXKxwiJ.xZf4.KN5q39PfeZB8Nv7LhPoD1Y./PS5lMmC', NULL, NULL, NULL),
(84, 'kr74z', '6do7', 'Jhp9aI@gmail.com', 6, '$2y$10$.8ac4EquHYt8i9mlYNFxQ.PEwvJqX/BLhWREdDz0Jl2ZvjsJ/lh.m', NULL, NULL, NULL),
(85, 'GKbDi', 'kgdz', 'NyBDbg@gmail.com', 9, '$2y$10$XIHPtFtVtL/4MbtNgu/gheWK2kDSh1wjiI9p9yoFAFt/m7O7jdPkK', NULL, NULL, NULL),
(86, 'bAfk0', 'SCXr', '74aJcV@gmail.com', 2, '$2y$10$F9xhvUR.vgE4QFEXoW4CfueoSqi83HAgNkYzI9RJyARgptb/H9I.y', NULL, NULL, NULL),
(87, 'qAQzw', 'P7JL', 'cR5i8K@gmail.com', 4, '$2y$10$gxc9xxYlEPs9DzpCRaQBu.2trOWA06WekLQE7jK0g6DDETvHigbly', NULL, NULL, NULL),
(88, 'mmo55', 'ShJT', 'PWmMFb@gmail.com', 5, '$2y$10$1Bl/Ai1sJLMv93RhQn3PmeeUuQIAiDc4VpJ4Aa7vBzAG8CWyJwlAa', NULL, NULL, NULL),
(89, '18bHe', 'T0OO', 'LqsJJN@gmail.com', 1, '$2y$10$pUDuACPJnBrrP1VRwK1MsepD5gHLwm3Kzx/CGW71daQpxv/Sd.yMq', NULL, NULL, NULL),
(90, 'SkRaI', 'bgVW', 'Rb6MGG@gmail.com', 7, '$2y$10$clpBfdHlPpes5jc11ICXJ.xWV86hsvTHdNcPlGkMiS1S4aHUbAHYu', NULL, NULL, NULL),
(91, 'bsu4r', 't0ve', 'vxSykl@gmail.com', 1, '$2y$10$VPB9iAcYtZdk7lFSCVRwDuup9Gyz1dOgxE4HNNcqEJheni28p9sES', NULL, NULL, NULL),
(92, 'Csq5z', 'tHOA', 'SiABAO@gmail.com', 3, '$2y$10$EKvbVmJixRRRUKxQV02hHOMF0/EPzhd.1mLe/FodJt/fi1Npc4DGO', NULL, NULL, NULL),
(93, '31nVC', 'i7fI', '0FewGd@gmail.com', 6, '$2y$10$3TuzUsHIX8n5Cpj94VsSHO7xdzdif1S2/V67RcHRoDV4v2jZLSdrK', NULL, NULL, NULL),
(94, 'XDlkf', 'MsVc', 'FjbHFD@gmail.com', 9, '$2y$10$uBii3V9xczExlADUzMOJMuUqiU/cPiPt8dkCwfTpSvvUXc78XYgJW', NULL, NULL, NULL),
(95, '4lAjN', 'mpjH', '633GKo@gmail.com', 8, '$2y$10$SFdjQi5zBBIMUhySRX/MXuPF8c3QafTpKYdMZyPu7VdH6u6Xc0YuO', NULL, NULL, NULL),
(96, 'fQenS', '4EhV', 'nFjBz6@gmail.com', 3, '$2y$10$m55VLdmzYl714fgQ6HnUWOq8C9SLZ54VMzYY3UORxd50p6i0St.oC', NULL, NULL, NULL),
(97, '4wgHc', 'VB7Q', 'lmyI80@gmail.com', 10, '$2y$10$4DFVyHsUMdR0cKspvOxSiOFVtXoDgTz2UGhN07PehajbzaNmeLZ/y', NULL, NULL, NULL),
(98, 'opSX7', 'ZXY2', 'VeVb5s@gmail.com', 8, '$2y$10$2FMvvWK88DpUGeyHkk6ktONOJn/5QfhPKR1k9oCsv83W3MceLz502', NULL, NULL, NULL),
(99, 'igN4j', '1UXa', 'mvD4is@gmail.com', 3, '$2y$10$K5nmRT8.ndYIjUtJ0YKhgOzu8VZy5MIYdLkKPlVIRj8ewDFTE0e46', NULL, NULL, NULL),
(100, 'UtTKP', 'byoO', 'YrAoeP@gmail.com', 6, '$2y$10$0C/r1U9qCTdPioAFv9ztpO9pWZwcGEC1SwjOKx0XxcnRO.5E2uG8i', NULL, NULL, NULL),
(101, 'ciF9K', 'sdu9', '3FV637@gmail.com', 3, '$2y$10$eU.AyO2YEtRGkSGdMXatnuglXJOyUF12KwK7LM7ChhdX32dC9Vujq', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_email_unique` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
